import 'dart:convert';
import 'package:http/http.dart' as http;

const _headers = {
  'User-Agent':
      'MuroBird/1.0 (https://example.com; contacto: dev@murobird.app)',
};

class GbifService {
  static Future<int?> fetchSpeciesKey(String scientificName) async {
    final name = scientificName.trim();
    if (name.isEmpty) return null;

    final uri = Uri.parse(
      'https://api.gbif.org/v1/species/match',
    ).replace(queryParameters: {'name': name});

    final r = await http.get(uri, headers: _headers);
    if (r.statusCode == 200) {
      final j = json.decode(r.body) as Map<String, dynamic>;
      final key = j['usageKey'];
      if (key is int) return key;
    }

    // fallback
    final sUri = Uri.parse(
      'https://api.gbif.org/v1/species/search',
    ).replace(queryParameters: {'q': name, 'limit': '1'});
    final sr = await http.get(sUri, headers: _headers);
    if (sr.statusCode != 200) return null;
    final sj = json.decode(sr.body) as Map<String, dynamic>;
    final results = (sj['results'] ?? []) as List;
    if (results.isEmpty) return null;
    final maybeKey = (results.first as Map<String, dynamic>)['key'];
    return (maybeKey is int) ? maybeKey : null;
  }
}
