import 'package:flutter/material.dart';
import '../../core/routes.dart';
import '../../core/theme.dart';

class SearchingScreen extends StatefulWidget {
  const SearchingScreen({super.key});

  @override
  State<SearchingScreen> createState() => _SearchingScreenState();
}

class _SearchingScreenState extends State<SearchingScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 2), () {
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, Routes.result);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBg,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(height: 16),
            const Text(
              'Estamos buscando las aves',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 22),
            // Logo pajarito
            CircleAvatar(
              radius: 48,
              backgroundColor: const Color.fromARGB(
                255,
                100,
                95,
                95,
              ).withOpacity(.12),
              child: Image.asset(
                'assets/images/murobird_sinfondo.png',
                width: 64,
                height: 64,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) =>
                    const Icon(Icons.podcasts_rounded, color: kBrand, size: 56),
              ),
            ),
            const SizedBox(height: 22),
            const Text(
              'Cargando... 99,99%',
              style: TextStyle(fontSize: 16, color: Colors.black54),
            ),
            const SizedBox(height: 24),
            const SizedBox(
              width: 38,
              height: 38,
              child: CircularProgressIndicator(color: kBrand),
            ),
          ],
        ),
      ),
    );
  }
}
