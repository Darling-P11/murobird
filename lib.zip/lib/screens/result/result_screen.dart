import 'package:flutter/material.dart';
import '../../core/theme.dart';

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  int current = 0;

  // Datos de ejemplo (puedes reemplazar paths / textos)
  final List<_BirdInfo> birds = [
    _BirdInfo(
      mainImage: 'assets/mock/bird_1.jpg',
      sideLeft: 'assets/mock/bird_2.jpg',
      sideRight: 'assets/mock/bird_3.jpg',
      commonTitleLeading: 'Colimbo grande',
      familyTitleTrailing: 'Gavias',
      familySci: 'Gaviidae',
      alsoKnown: 'Colimbo Común, Colimbo mayor',
      scientific: 'Gavia immer',
      description:
          'El colimbo grande, conocido también como gran bribón septentrional o bribón común (Gavia immer), es una especie de ave gaviiforme de la familia Gaviidae propia de América del Norte y Europa. Es un ave acuática migratoria que cría en los lagos de Norteamérica, Groenlandia, Islandia y Gran Bretaña y en invierno migra a ambas costas del Atlántico norte y a la del Pacífico nororiental y lagos más meridionales.',
      gallery: [
        'assets/mock/bird_1.jpg',
        'assets/mock/bird_2.jpg',
        'assets/mock/bird_3.jpg',
        'assets/mock/bird_4.jpg',
      ],
      mapImage: 'assets/mock/mapa_demo.png',
    ),
    _BirdInfo(
      mainImage: 'assets/mock/bird_2.jpg',
      sideLeft: 'assets/mock/bird_3.jpg',
      sideRight: 'assets/mock/bird_1.jpg',
      commonTitleLeading: 'Petirrojo europeo',
      familyTitleTrailing: 'Erithacus',
      familySci: 'Muscicapidae',
      alsoKnown: 'Raitán, Paporrubio',
      scientific: 'Erithacus rubecula',
      description:
          'Pequeño paseriforme muy confiado. Canta todo el año con trinos melódicos. Se asocia a jardines y bosques templados.',
      gallery: [
        'assets/mock/bird_2.jpg',
        'assets/mock/bird_1.jpg',
        'assets/mock/bird_4.jpg',
        'assets/mock/bird_3.jpg',
      ],
      mapImage: 'assets/mock/mapa_demo.png',
    ),
    _BirdInfo(
      mainImage: 'assets/mock/bird_4.jpg',
      sideLeft: 'assets/mock/bird_3.jpg',
      sideRight: 'assets/mock/bird_2.jpg',
      commonTitleLeading: 'Reinita anaranjada',
      familyTitleTrailing: 'Icterus',
      familySci: 'Icteridae',
      alsoKnown: 'Bolsero',
      scientific: 'Icterus galbula',
      description:
          'Colorido icterino de bosques abiertos; su canto es silbado y alegre. Frecuente en migración.',
      gallery: [
        'assets/mock/bird_4.jpg',
        'assets/mock/bird_2.jpg',
        'assets/mock/bird_1.jpg',
        'assets/mock/bird_3.jpg',
      ],
      mapImage: 'assets/mock/mapa_demo.png',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final b = birds[current];

    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // ======= ENCABEZADO (gradiente + fotos circulares + "píldora" con título) =======
            SliverToBoxAdapter(
              child: _Header(
                info: b,
                index: current,
                total: birds.length,
                onBack: () => Navigator.pop(context),
                onPickIndex: (i) => setState(() => current = i),
                onShare: () {}, // TODO: compartir
              ),
            ),

            // ======= CONTENIDO =======
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Sonido
                    const _SectionTitle(
                      icon: Icons.podcasts_rounded,
                      title: 'Sonido',
                    ),
                    const SizedBox(height: 10),
                    _AudioBar(),
                    const SizedBox(height: 24),

                    // Espectrograma
                    const _SectionTitle(
                      icon: Icons.show_chart,
                      title: 'Espectrograma',
                    ),
                    const SizedBox(height: 10),
                    _Spectrogram(),
                    const SizedBox(height: 24),

                    // Descripción
                    const _SectionTitle(
                      icon: Icons.menu_book_rounded,
                      title: 'Descripción',
                    ),
                    const SizedBox(height: 10),
                    Text(
                      b.description,
                      style: const TextStyle(
                        fontSize: 16,
                        height: 1.35,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 24),

                    // Galería
                    const _SectionTitle(
                      icon: Icons.photo_camera_back_rounded,
                      title: 'Galería del ave',
                    ),
                    const SizedBox(height: 12),
                    _GalleryGrid(images: b.gallery),
                    const SizedBox(height: 24),

                    // Mapa
                    const _SectionTitle(
                      icon: Icons.public,
                      title: 'Mapa de distribución',
                    ),
                    const SizedBox(height: 12),
                    _MapCard(image: b.mapImage),
                    const SizedBox(height: 26),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/* ====================================================================== */
/* ============================== WIDGETS ================================ */
/* ====================================================================== */

class _Header extends StatelessWidget {
  const _Header({
    required this.info,
    required this.index,
    required this.total,
    required this.onBack,
    required this.onPickIndex,
    required this.onShare,
  });

  final _BirdInfo info;
  final int index;
  final int total;
  final VoidCallback onBack;
  final ValueChanged<int> onPickIndex;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 340,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          // Fondo con gradiente
          Container(
            height: 240,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFFACF0E4), Color(0xFF78B4D6)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // Flecha atrás (izquierda)
          Positioned(
            top: 8,
            left: 8,
            child: IconButton(
              style: IconButton.styleFrom(
                backgroundColor: Colors.white.withOpacity(.85),
                shape: const CircleBorder(),
                fixedSize: const Size(44, 44),
              ),
              onPressed: onBack,
              icon: const Icon(Icons.arrow_back, color: kBrand, size: 24),
            ),
          ),

          // Avatares laterales
          Positioned(
            left: -28,
            top: 70,
            child: _SideAvatar(path: info.sideLeft),
          ),
          Positioned(
            right: -28,
            top: 70,
            child: _SideAvatar(path: info.sideRight),
          ),

          // Avatar principal
          Positioned(
            top: 36,
            left: 0,
            right: 0,
            child: _MainAvatar(path: info.mainImage),
          ),

          // Indicadores 1 - 2 - 3
          Positioned(
            top: 220,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                total,
                (i) => Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: _IndexDot(
                    label: '${i + 1}',
                    selected: i == index,
                    onTap: () => onPickIndex(i),
                  ),
                ),
              ),
            ),
          ),

          // Tarjeta “píldora” de título y metadatos
          Positioned(
            left: 12,
            right: 12,
            top: 248,
            child: _TitlePill(
              titleLeading: info.commonTitleLeading,
              titleFamily: info.familyTitleTrailing,
              familySci: info.familySci,
              alsoKnown: info.alsoKnown,
              scientific: info.scientific,
              onShare: onShare,
            ),
          ),
        ],
      ),
    );
  }
}

class _SideAvatar extends StatelessWidget {
  const _SideAvatar({required this.path});
  final String path;
  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 42,
      backgroundColor: Colors.white,
      child: ClipOval(child: _img(path, size: 76, cover: true)),
    );
  }
}

class _MainAvatar extends StatelessWidget {
  const _MainAvatar({required this.path});
  final String path;
  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 78,
      backgroundColor: Colors.white,
      child: ClipOval(child: _img(path, size: 150, cover: true)),
    );
  }
}

class _IndexDot extends StatelessWidget {
  const _IndexDot({
    required this.label,
    required this.selected,
    required this.onTap,
  });
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          boxShadow: selected
              ? const [
                  BoxShadow(
                    color: Color(0x33000000),
                    blurRadius: 6,
                    offset: Offset(0, 2),
                  ),
                ]
              : null,
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: selected ? kBrand : Colors.black87,
          ),
        ),
      ),
    );
  }
}

class _TitlePill extends StatelessWidget {
  const _TitlePill({
    required this.titleLeading,
    required this.titleFamily,
    required this.familySci,
    required this.alsoKnown,
    required this.scientific,
    required this.onShare,
  });

  final String titleLeading;
  final String titleFamily;
  final String familySci;
  final String alsoKnown;
  final String scientific;
  final VoidCallback onShare;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 5,
      borderRadius: BorderRadius.circular(22),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(18, 16, 10, 16),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Texto
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Título con pesos diferentes e itálicas
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 20,
                        height: 1.25,
                      ),
                      children: [
                        TextSpan(
                          text: '$titleLeading, ',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        const TextSpan(text: 'una especie de '),
                        TextSpan(
                          text: '$titleFamily ',
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        TextSpan(
                          text: '($familySci)',
                          style: const TextStyle(fontStyle: FontStyle.italic),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 16,
                      ),
                      children: [
                        const TextSpan(text: 'También conocido como: '),
                        TextSpan(
                          text: alsoKnown,
                          style: const TextStyle(color: Colors.black87),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  RichText(
                    text: TextSpan(
                      style: const TextStyle(
                        color: Colors.black54,
                        fontSize: 16,
                      ),
                      children: [
                        const TextSpan(text: 'Nombre científico: '),
                        TextSpan(
                          text: scientific,
                          style: const TextStyle(
                            color: Colors.black87,
                            fontStyle: FontStyle.italic,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            // Compartir
            IconButton(
              onPressed: onShare,
              icon: const Icon(Icons.share_outlined),
              splashRadius: 20,
              color: Colors.black87,
            ),
          ],
        ),
      ),
    );
  }
}

/* ---------------- Secciones de contenido ---------------- */

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.icon, required this.title});
  final IconData icon;
  final String title;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: Colors.black87),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: Colors.black87,
          ),
        ),
      ],
    );
  }
}

class _AudioBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: kBrand,
                shape: BoxShape.circle,
              ),
              child: const Icon(Icons.play_arrow, color: Colors.white),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(
                  value: .45,
                  minHeight: 6,
                  color: kBrand,
                  backgroundColor: const Color(0xFFE7F3F0),
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              '00:10',
              style: TextStyle(
                color: Colors.black54,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Spectrogram extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(6),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: _img(
          'assets/mock/spectrogram_demo.png',
          height: 140,
          cover: true,
        ),
      ),
    );
  }
}

class _GalleryGrid extends StatelessWidget {
  const _GalleryGrid({required this.images});
  final List<String> images;

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      itemCount: images.length,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      padding: EdgeInsets.zero,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 16,
        crossAxisSpacing: 16,
        childAspectRatio: 1.2,
      ),
      itemBuilder: (_, i) => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: _img(images[i], cover: true),
      ),
    );
  }
}

class _MapCard extends StatelessWidget {
  const _MapCard({required this.image});
  final String image;

  @override
  Widget build(BuildContext context) {
    return Material(
      elevation: 2,
      borderRadius: BorderRadius.circular(12),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(12),
        child: _img(image, height: 190, cover: true),
      ),
    );
  }
}

/* ================= util img ================= */

Widget _img(String path, {double? size, double? height, bool cover = false}) {
  final w = size;
  final h = size ?? height;
  return Image.asset(
    path,
    width: w,
    height: h,
    fit: cover ? BoxFit.cover : BoxFit.contain,
    errorBuilder: (_, __, ___) => Container(
      width: w,
      height: h,
      color: const Color(0xFFEFF3F2),
      alignment: Alignment.center,
      child: const Icon(
        Icons.image_not_supported_outlined,
        color: Colors.black26,
      ),
    ),
  );
}

/* ================= modelo simple ================= */

class _BirdInfo {
  final String mainImage;
  final String sideLeft;
  final String sideRight;

  final String commonTitleLeading;
  final String familyTitleTrailing;
  final String familySci;

  final String alsoKnown;
  final String scientific;
  final String description;

  final List<String> gallery;
  final String mapImage;

  _BirdInfo({
    required this.mainImage,
    required this.sideLeft,
    required this.sideRight,
    required this.commonTitleLeading,
    required this.familyTitleTrailing,
    required this.familySci,
    required this.alsoKnown,
    required this.scientific,
    required this.description,
    required this.gallery,
    required this.mapImage,
  });
}
