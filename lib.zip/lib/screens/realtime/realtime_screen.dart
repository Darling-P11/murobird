import 'package:flutter/material.dart';
import '../../core/routes.dart';
import '../../core/theme.dart';

class RealtimeScreen extends StatelessWidget {
  const RealtimeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Como en el mock: fondo blanco y SIN AppBar
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            // ====== Contenido ======
            ListView(
              padding: const EdgeInsets.fromLTRB(22, 24, 22, 22),
              children: [
                // Título: ESPECTROGRAMA
                const _SectionHeader('ESPECTROGRAMA'),
                const SizedBox(height: 12),

                // Imagen grande del espectrograma (igual al mock)
                Container(
                  height: 180,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: Colors.black54, width: 1.2),
                  ),
                  clipBehavior: Clip.antiAlias,
                  child: Image.asset(
                    'assets/mock/spectrogram_demo.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => const Center(
                      child: Text(
                        'imagen espectrograma',
                        style: TextStyle(color: Colors.black45),
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 28),

                // Título: ONDA DE SONIDO
                const _SectionHeader('ONDA DE SONIDO'),
                const SizedBox(height: 12),

                // Onda grande (sin tarjeta)
                SizedBox(
                  height: 120,
                  child: Center(
                    child: Image.asset(
                      'assets/mock/wave_demo.png',
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.graphic_eq,
                        size: 56,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                // Botón "ave identificada" (píldora verde)
                Center(
                  child: SizedBox(
                    height: 44,
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kBrand,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 22),
                        shape: const StadiumBorder(),
                        elevation: 0,
                        textStyle: const TextStyle(
                          fontWeight: FontWeight.w800,
                          fontSize: 16,
                        ),
                      ),
                      onPressed: () =>
                          Navigator.pushNamed(context, Routes.searching),
                      child: const Text('ave identificada'),
                    ),
                  ),
                ),

                const SizedBox(height: 40),

                // Tiempo
                const Center(
                  child: Text(
                    '00:00:00',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.w800,
                      color: Colors.black54,
                      letterSpacing: 1.0,
                    ),
                  ),
                ),
                const SizedBox(height: 10),

                // Instrucción
                const Center(
                  child: Text(
                    'Pulsa para empezar a captar el\nsonido del pájaro',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.black45,
                      fontSize: 16,
                      height: 1.25,
                    ),
                  ),
                ),

                const SizedBox(height: 18),

                // Botón micrófono redondo (grande)
                Center(
                  child: Container(
                    width: 84,
                    height: 84,
                    decoration: const BoxDecoration(
                      color: kBrand,
                      shape: BoxShape.circle,
                    ),
                    child: const Center(
                      child: Icon(Icons.mic, color: Colors.white, size: 36),
                    ),
                  ),
                ),
              ],
            ),

            // ====== Botón cerrar (X) arriba a la derecha, como el mock ======
            Positioned(
              top: 8,
              right: 8,
              child: IconButton(
                style: IconButton.styleFrom(
                  backgroundColor: const Color(0xFFBDBDBD), // gris
                  shape: const CircleBorder(),
                  fixedSize: const Size(40, 40),
                ),
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.close, color: Colors.white),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      textAlign: TextAlign.center,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w900,
        color: Colors.black54,
        letterSpacing: 1.0,
      ),
    );
  }
}
